<?php

namespace App\Support;

class AttendanceStatus
{
    private const LABELS = [
        'present' => 'Hadir',
        'late' => 'Terlambat',
        'absent' => 'Tidak Hadir',
        'leave' => 'Izin',
        'sick' => 'Sakit',
    ];

    private const BADGES = [
        'present' => 'badge-green',
        'late' => 'badge-yellow',
        'absent' => 'badge-red',
        'leave' => 'badge-blue',
        'sick' => 'badge-blue',
    ];

    public static function options(): array
    {
        return self::LABELS;
    }

    public static function label(?string $status): string
    {
        $status = strtolower(trim((string) $status));

        if ($status === '') {
            return '-';
        }

        return self::LABELS[$status] ?? ucfirst($status);
    }

    public static function badge(?string $status): string
    {
        $status = strtolower(trim((string) $status));

        return self::BADGES[$status] ?? 'badge-gray';
    }
}
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Employee extends Model
{
    use HasFactory;

    protected $fillable = [
        'employee_code',
        'full_name',
        'department',
        'is_active',
        'work_schedule_id',
    ];

    protected $casts = [
        'is_active' => 'boolean',
    ];

    public function workSchedule()
    {
        return $this->belongsTo(
            WorkSchedule::class,
            'work_schedule_id'
        );
    }

    public function attendanceSessions()
    {
        return $this->hasMany(
            AttendanceSession::class
        );
    }
}